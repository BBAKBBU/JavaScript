const title = document.querySelector("h1");

title.addEventListener("click", () => {
  title.remove();
});