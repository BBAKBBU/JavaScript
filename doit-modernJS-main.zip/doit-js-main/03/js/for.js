const students = ["Park", "Kim", "Lee", "Kang"];   

for (let i = 0; i < students.length; i++) { 
  document.write(`${students[i]}<br>`);
}