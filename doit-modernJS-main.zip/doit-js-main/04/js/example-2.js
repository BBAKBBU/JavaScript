let multiple = (a, b) => a * b;

console.log(`두 수를 곱한 결과는 ${multiple(10, 20)}입니다.`);