let sum = (a, b) => {
  let result = a + b;
  return result;
};

