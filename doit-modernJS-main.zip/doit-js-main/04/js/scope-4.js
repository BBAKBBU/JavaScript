function greeting() {
  hi = "hello";   // 전역 변수로 인식  
}
greeting();
console.log(hi);