function sum(a, b) {
  var result = a + b;
}
sum(10, 20);
console.log(result);