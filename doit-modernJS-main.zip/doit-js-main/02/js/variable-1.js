function add(a, b) {
  return a + b;
}

var sum = add(10, 20);
console.log(sum);
var sum = 100;   // var 변수는 재선언, 재할당 가능
console.log(sum);