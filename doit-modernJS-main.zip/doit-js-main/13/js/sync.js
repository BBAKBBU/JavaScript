function displayA() {
  console.log("A");
}
function displayB() {
  console.log("B");
}
function displayC() {
  console.log("C");
}
displayA();
displayB();
displayC();