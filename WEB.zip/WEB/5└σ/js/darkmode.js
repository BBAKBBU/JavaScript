const bttn = document.querySelector("button");

bttn.onclick = function(){
    document.boby.classList.toggle("dark");
}