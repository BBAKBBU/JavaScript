const bttn = document.querySelector("button");

bttn.addEventListener("click", () => {
    alert("클릭했습니다");
});