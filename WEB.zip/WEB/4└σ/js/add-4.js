let sum = function(a, b){
    return a + b;
}
console.log(`함수 실행 결과 : ${sum(10, 20)}`)