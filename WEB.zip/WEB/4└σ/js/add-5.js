(function(a, b){
    let sum = a+b;
    console.log(`함수 실행 결과 : %{sum}`)
}) (100, 200);