setTimeout(() => {
    console.log("반가워요.");
}, 3000); //5초 후 함수 실행