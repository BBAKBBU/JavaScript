function sum(a, b) {
    var result = a + b;
}
console.log(result);