const bttn = document.querySelector("button");

function display(){
    alert("클릭했습니다.");
}

bttn.addEventListener("click", display);