const factor = 5;

function calc(num){
    return num*factor;
}
{
    let result = calc(10);
    document.write(`result : ${result}`);
}