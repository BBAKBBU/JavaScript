var hi = "hello"; //전역 변수

function greeting() {
    console.log(hi); //hi의 내용이 출력되내?
}
greeting(); //함수 호출)