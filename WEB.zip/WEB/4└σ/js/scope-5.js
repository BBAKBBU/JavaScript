const factor = 5

function calc(){
    return num*factor;
}
{
    const num = 10;
    let result = calc();
    document.write(`result : ${result}`);
}