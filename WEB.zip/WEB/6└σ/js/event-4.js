const button = document.querySelector("button");

button.onlick = function(){
    document.body.style.backgroundColor = "green";
}